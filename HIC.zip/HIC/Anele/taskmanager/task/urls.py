from django.urls import path
from . import views
from django.contrib.auth.views import LoginView, LogoutView

urlpatterns = [
    # Home, About, and Task pages
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    #path('task/', views.task, name='task'),
    #path('tasks/', views.tasks_view, name='tasks'), 
    path('contact/', views.contact, name='contact'),
    #path('create-task/', views.create_task, name='create_task'),  # Add this line
    path('task/<int:task_id>/complete/', views.mark_complete, name='mark_complete'),
    path('task/', views.task_view, name='task_view'),
   # path('create-task/', views.dashboard, name='dashboard'),
    path('dashboard/', views.dashboard, name='dashboard'),
    # Login, Register, and Dashboard pages
    path('login/', views.custom_login, name='login'),
    path('register/', views.register_view, name='register'),
    #path('dashboard/', views.dashboard_view, name='dashboard'),  # Assuming you have a separate dashboard view
    path('create-task/', views.dashboard, name='create_task'),
    # Logout (with confirmation message)
    path('logout/', views.custom_logout, name='logout'),  # Ensure you have a custom logout view
    path('focus/', views.focus_mode, name='focus_mode'),
]
