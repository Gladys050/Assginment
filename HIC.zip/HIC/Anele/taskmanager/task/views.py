from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseRedirect
from django.contrib import messages
from datetime import datetime
from .models import FocusMode

from .forms import TaskForm
from .models import Task  # ✅ Corrected import

def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

@login_required
def create_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task_name = form.cleaned_data['task_name']
            task_description = form.cleaned_data['task_description']
            priority = form.cleaned_data['priority']
            due_date = form.cleaned_data['due_date']

            priority_color = {'high': 'red', 'medium': 'yellow', 'low': 'green'}.get(priority, 'gray')
            today = datetime.today().date()
            days_left = (due_date - today).days

            # Create the task
            Task.objects.create(
                name=task_name,
                description=task_description,
                priority=priority,
                due_date=due_date,
                user=request.user,
            )

            # Fetch all tasks for the logged-in user
            tasks = Task.objects.filter(user=request.user)

            return render(request, 'create_task.html', {
                'form': form,
                'priority_color': priority_color,
                'task_name': task_name,
                'priority': priority,
                'due_date': due_date,
                'days_left': days_left,
                'tasks': tasks,  # Pass all tasks to the template
            })
    else:
        form = TaskForm()
    
    return render(request, 'create_task.html', {'form': form})


@login_required
def task_view(request):
    tasks = Task.objects.filter(user=request.user)
    return render(request, 'dashboard.html', {'tasks': tasks})

@login_required
def mark_complete(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    task.completed = True
    task.save()
    return redirect('task_view')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)
            return redirect('task_view')  # This should redirect to 'task_view' after successful login
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'login.html')

def register_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 != password2:
            messages.error(request, "Passwords do not match.")
        elif User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
        elif User.objects.filter(email=email).exists():
            messages.error(request, "Email already in use.")
        else:
            user = User.objects.create_user(username=username, email=email, password=password1)
            messages.success(request, "Account created!")
            login(request, user)
            return redirect('task_view')  # Redirect to task view after registration
    return render(request, 'register.html')

@login_required
def custom_logout(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect('home')

def custom_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            messages.success(request, "Login successful!")
            return redirect('task_view')  # Redirect to task view (previously 'tasks')
        else:
            messages.error(request, "Invalid username or password")
            return redirect('login')

    return render(request, 'login.html')

def dashboard(request):
    if request.method == 'POST':
        task_name = request.POST['task_name']
        due_date = request.POST.get('due_date', None)
        reminder = request.POST.get('reminder', None)
        recurrence = request.POST.get('recurrence', None)

        # Ensure the user is logged in
        if request.user.is_authenticated:
            # Create a new task for the logged-in user
            Task.objects.create(
                user=request.user,  # Associate the task with the logged-in user
                name=task_name, 
                due_date=due_date, 
                reminder=reminder, 
                recurrence=recurrence
            )
            return redirect('dashboard')  # Redirect after POST

    tasks = Task.objects.filter(user=request.user)  # Fetch tasks for the logged-in user
    return render(request, 'task/dashboard.html', {'tasks': tasks})

def focus_mode(request):
    if request.method == 'POST':
        task_name = request.POST['task_name']
        FocusMode.objects.create(task_name=task_name)
        return redirect('focus_mode')

    focus_task = FocusMode.objects.last()  # Or filter based on user if needed
    current_time = datetime.now().strftime('%H:%M:%S')

    context = {
        'focus_task': focus_task,
        'current_time': current_time
    }

    return render(request, 'focus_mode.html', context)