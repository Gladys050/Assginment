from django import forms
from .models import Task 

PRIORITY_CHOICES = [
    ('high', 'High'),
    ('medium', 'Medium'),
    ('low', 'Low'),
]

class TaskForm(forms.Form):
    task_name = forms.CharField(max_length=100)
    task_description = forms.CharField(widget=forms.Textarea)
    priority = forms.ChoiceField(choices=PRIORITY_CHOICES)
    due_date = forms.DateField(widget=forms.SelectDateWidget)  # This will create a date picker
